<?include("../menu.inc");

$result=mysql_query("SELECT * FROM entradas_y_salidas where;");	

?>