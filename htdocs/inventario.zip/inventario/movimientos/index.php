<HTML>
<head>
</head>
<body>
<p>
<a href="eci.php">entradas al almacen general</a>
<p>
<a href="dpi.php">salidas del almacen general por devolucion</a>
<p>
<a href="vmi.php">salidas por venta de mostrador</a>
<p>
<a href="sti.php">salidas por traspaso</a>
<p>
<a href="edi.php">entradas diversas</a>
<p>
<a href="sdi.php">salidas diversas</a>
</HTML>

