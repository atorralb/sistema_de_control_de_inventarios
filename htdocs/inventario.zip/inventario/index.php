<?php include("indexmenu.inc");?>
<title>inicio</title>
<strong>INVENTARIO PARA NATURALMENTE</STRONG>
<P>
<STRONG>USANDO TECNOLOGIA:</strong></font><P>
<br>
<body>
<img align=center src="/images/apacheanimation.gif"></img>
<p>

<img align=center src="/images/mysql.gif"></img>
<img align=center src="/images/php.gif"></img>
<img align=center src="/images/phpnuke.gif"></img>
<img align=center src="/images/a2triad.gif"></img>
<a href="/chat/html"><img align=center src="/images/phpopenchat.gif" border=0></img></a>
<br>


   <script type="text/javascript">
    var ddmx = new DropDownMenuX('menu1');
    ddmx.delay.show = 0;
    ddmx.delay.hide = 400;
    ddmx.position.levelX.left = 2;
    ddmx.init();
    </script>

</body>
</html>