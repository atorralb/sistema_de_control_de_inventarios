
<?php
/*
03.
-----------------
04.
Language: Spanish
05.
-----------------
06.
*/
$lang = array();
$lang['PAGE_TITLE'] = 'Título de la página de mi sitio web';

$lang['HEADER_TITLE'] = 'Mi sitio web de la cabecera título';

$lang['SITE_NAME'] = 'Mi Sitio Web';

$lang['SLOGAN'] = 'Mi lema aquí';

$lang['HEADING'] = 'Título';

$lang['MENU_HOME'] = 'Inicio';

$lang['MENU_ABOUT_US'] = 'Sobre Nosotros';

$lang['MENU_OUR_PRODUCTS'] = 'Nuestros productos';

$lang['MENU_CONTACT_US'] = 'Contáctenos';

$lang['MENU_ADVERTISE'] = 'Publicidad';

$lang['MENU_SITE_MAP'] = 'Mapa del Sitio';

?>