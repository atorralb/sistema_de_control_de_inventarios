Fancy Input
=============
Makes typing in input / Textarea fields fun with CSS3 effects. Deleting is also fun!

##[Demo page](http://dropthebit.com/demos/fancy_input/fancyInput.html)

## Basic use-case example:
    <div>
		<input type='text' />
	</div>
	<div>
		<textares></textarea
	</div>
    <script>
        $('div :input').fancyInput();
    </script>
	
This will add the 'fancyInput' class to all parents of inputs. make sure every input is actually wrapped in a div before...

(this plugin does not support any version of IE)
